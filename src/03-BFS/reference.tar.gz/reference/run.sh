./bfs_main.out < data/citationCiteseer.graph
